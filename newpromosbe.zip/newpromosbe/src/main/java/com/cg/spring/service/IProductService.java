package com.cg.spring.service;

import com.cg.spring.beans.Product;

public interface IProductService {

	

	Product showcamera();

	Product showcameras();

	Product showphone();

	Product showphones();

	Product showshoe();

	Product showshoes();

}
